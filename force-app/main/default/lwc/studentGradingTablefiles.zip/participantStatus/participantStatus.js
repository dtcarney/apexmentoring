import { LightningElement, api, wire, track } from 'lwc';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import STATUS_FIELD from '@salesforce/schema/Participant__c.Status__c'; // Use the correct object and field API names

export default class ParticipantStatus extends LightningElement {
    @api value; // Current value of the picklist field for the record
    @api recordId; // Record ID for the row in the datatable
    @track options = []; // Array to store picklist options

    // Fetch picklist values using @wire without specifying a record type
    @wire(getPicklistValues, { recordTypeId: null, fieldApiName: STATUS_FIELD })
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.options = data.values; 
            console.log('Fetched picklist options:', this.options); // Log to confirm options
        } else if (error) {
            console.error('Error fetching picklist values:', error);
        }
    }
    connectedCallback() {
        console.log('ParticipantStatus component connected');
        // Temporary static options to confirm combobox renders correctly
        console.log('Fetched picklist options connected:', this.options);
    }


    // Event handler for combobox change
    handleChange(event) {
        const selectedValue = event.detail.value;
        console.log("Dispatching picklistchange event with:", selectedValue, this.recordId);


        // Dispatch an event with the selected picklist value and record ID
        this.dispatchEvent(
            new CustomEvent('picklistchange', {
                detail: { value: selectedValue, recordId: this.recordId }
            })
        );
    }
}
