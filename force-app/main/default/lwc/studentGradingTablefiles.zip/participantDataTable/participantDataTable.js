import LightningDatatable from 'lightning/datatable';
import participantStatus from './templates/participantStatus.html';

export default class ParticipantDataTable extends LightningDatatable {
    static customTypes = {
        customPicklist: {
            template: participantStatus,
            typeAttributes: ['value', 'recordId']
        }
    };

    connectedCallback() {
        console.log('ParticipantDataTable component initialized');
    }
}
